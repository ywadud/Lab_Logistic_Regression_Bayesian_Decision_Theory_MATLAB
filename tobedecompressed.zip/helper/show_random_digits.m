%%% show_random_digits
%
% Function that shows 100 random digits for each digit 0, 1, ..., 9
% given a 3D matrix of digits and their associated true labels in a MATLAB
% figure.
%
% X - A 3D matrix of digit images
% y - The true labels for each digit where there are as many elements
% as there are digits

function show_random_digits(X, y)
% Spawn a new figure
figure(1);

% Get dimensions of an image
rows = size(X,1);
cols = size(X,2);

% For each digit
for ii = 0 : 9
    % Get all of the digits equal to the ith digit
    ind = y == ii;
    
    % Subsample and grab these digits
    digits = X(:,:,ind);
    
    % Total number of images that belong to this digit
    N = size(digits,3);
    
    % Randomly sample 100 digits
    samples = randperm(N, 100);
    digits_final = digits(:,:,samples);
    
    % Create an image and show on the screen
    img = zeros(10*rows,10*cols);
    % Place each digit in the right spot
    for jj = 1 : 10
        for kk = 1 : 10
            img((jj-1)*rows + 1 : jj*rows, (kk-1)*cols + 1 : kk*cols) = ...
                digits_final(:,:,(jj-1)*10 + kk);
        end
    end
    
    % Show the image on the screen
    imagesc(img);
    colormap gray;
    s = sprintf('Showing 100 random digits for digit %d', ii);
    title(s);
    
    % Remove the axes labels
    set(gca,'XTickLabel',[])
    set(gca,'YTickLabel',[])
   
    % Print status message to the screen
    fprintf(s);
    fprintf('\nPress any key to continue\n');    
    
    % Wait for a button press before we proceed
    waitforbuttonpress; 
end

end