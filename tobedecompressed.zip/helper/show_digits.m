%%% show_digits
%
% Function that randomly shows n digits in a square grid if possible in a
% MATLAB figure
%
% Inputs:
% X - A 3D matrix of digit images
% n - The total number of images you want to display

function show_digits(X, n)

% Determine how many rows/columns we should occupt in this image
row = ceil(sqrt(n));

% Generate n random indices to access the matrix
ind = randperm(size(X,3), n);

% Get rows and columns of an image
rows = size(X,1);
cols = size(X,2);

% Create the right sized image to place our digit images in
out = zeros(row*rows, row*cols);

% For each image from 1 up to n...
counter = 1;
for ii = 1 : row
    for jj = 1 : row
        if counter <= n
            % Get the ith random image and place it in its corresponding
            % location in the output. We populate from left to right, top
            % to bottom.
            out((ii-1)*rows + 1 : ii*rows, (jj-1)*cols + 1 : jj*cols) = ...
                X(:,:,ind(counter));
            counter = counter + 1;
        end
    end
end

% Show the figure with a gray colour map
% Remove the ticks and place a title illustrating how many random digits
% were chosen.
imagesc(out);
colormap gray;
set(gca, 'XTickLabel', []);
set(gca, 'YTickLabel', []);
title(sprintf('Showing %d random digits', n));


