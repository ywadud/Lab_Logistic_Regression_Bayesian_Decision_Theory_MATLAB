%%% calculate_decision_boundary
%
% Given the mean, variance and prior probabilities for two classes, this
% creates an anonymous function to be returned to the user for use in
% binary classification of single feature inputs with Bayesian Decision
% Theory.  The features are assumed to be Gaussian distributed
%
% Inputs:
% mu1, var1, pw1 - Mean, variance and prior probability for class 1
% mu2, var2, pw2 - Mean, variance and prior probability for class 2
%
% Outputs:
% p - Anonymous function that can be used to determine what class an input
% feature belongs to
function p = calculate_decision_boundary(mu1, var1, pw1, mu2, var2, pw2)

% Build quadratic equation and find the roots
A = (0.5/var2) - (0.5/var1);
B = (mu1/var1) - (mu2/var2);
C = 0.5*log(var2/var1) + log(pw1/pw2) - (mu1^2/(2*var1)) + ...
    (mu2^2/(2*var2));

x = roots([A B C]);

% Create classification function
p = @(y) ((y - x(1)).*(y - x(2)) < 0) + 1;

end