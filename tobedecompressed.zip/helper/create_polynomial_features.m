%%% create_polynomial_features
%
% Given two column vectors of equal length where each vector is a
% particular feature, the output is to create a data matrix where each
% column is either a feature raised to an integer power or a product of the
% two features both raised to an arbitrary power. This essentially
% introduces polynomial features into the data matrix.
%
% Inputs:
% X1, X2 - Two column vectors of equal length representing different
% features
% n - Highest order of polynomial we want to consider
%
% Outputs:
% X - Output data matrix conforming to the polynomial feature creation as
% discussed.

function X = create_polynomial_features(X1, X2, n)

% Generate all possible pairs of i and j for i = 0, 1, ... n
% and j = 0, 1, ..., n
[XX,YY] = ndgrid(0:n);
XX = XX(:); YY = YY(:);

% Get total number of new features - (n x 1) x (n x 1)
mp = numel(XX);

% Get total number of examples
m = numel(X1);

% Create a m x [(n x 1) x (n x 1)] matrix that stores our new features
X = zeros(m, mp);

% Populate our matrix where each column has features x_1^i * x_2^j for all
% training examples
for ii = 1 : mp
    x = XX(ii); y = YY(ii);
    X(:,ii) = X1.^(x) .* X2.^(y);
end

end