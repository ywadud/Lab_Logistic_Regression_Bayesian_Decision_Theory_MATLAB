%%% show_misclassified_digits
%
% Function where given an input digit to focus on, we show up to K digits
% that were misclassified.  Given a 3D matrix of digit images, as well as
% the labels for each image that were predicted using our multi-class 
% prediction system and the true labels available from a dataset, this
% produces a MATLAB figure that illustrates which digits were misclassified
% for a particular digit as well as what those predictions are.
%
% Inputs:
% X - A 3D matrix of digit images
% ypredict - The predicted labels for each digit where there are as many
% elements as there are digits
% ytrue - The true labels for each digit where there are as many elements
% as there are digits
% digit - The specific digit you want to look at for any misclassifications
% N - The largest amount of misclassifications to be displayed in the
% figure.  Should there be less than N misclassified images, only show up
% to that amount.

function show_misclassified_digits(X, ypredict, ytrue, digit, N)

% Ensure that the total number of predicted labels match the true 
% labels
if numel(ypredict) ~= numel(ytrue)
    error('Ensure that the total number of predicted labels match the number of true labels');
end

% Determine the best square dimensions of the figure to place our results
n = ceil(sqrt(N));

% Find all of the digits that correspond to the true digit label
loc = ytrue == digit;

% Look into the predictions and see find the mismatches
labels = ypredict(loc);
ind = labels ~= digit;
lbl = labels(ind);

% If there were some misclassifications...
if ~isempty(ind)
    % Do the same for the actual digit images themselves
    % Get the images that are supposed to belong to the digit but
    % got misclassified
    digits = X(:,:,loc);
    digits = digits(:,:,ind);
    
    % Ensure we only show up to as many misclassified images if we 
    % go over the limit
    if N > size(digits,3);
        N = size(digits,3);
    end
else
    % No misclassification case
    N = 0;
end

% For each digit, place into corresponding spot
figure;
if N == 0
    % If there are no mismatches, just show a gray figure
    O = 60*ones(2,2);
    image(O);
    colormap gray;
    set(gca, 'XTickLabel', []);
    set(gca, 'YTickLabel', []);    
    set(gca, 'XTick', []);
    set(gca, 'YTick', []);    
else
    % Cycle through each mismatched image and show the predicted label
    % as the title and the true digit
    for ii = 1 : N
        subplot(n,n,ii);
        imagesc(digits(:,:,ii));
        colormap gray;
        title(sprintf('Predicted Label: %d', lbl(ii)));
        set(gca, 'XTickLabel', []);
        set(gca, 'YTickLabel', []);
    end
end

% Place an overall title at the top of the figure
suptitle(sprintf('Showing %d misclassified digits for digit %d', N, digit));

end