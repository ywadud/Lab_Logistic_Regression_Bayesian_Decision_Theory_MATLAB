function [cost, grad] = univariate_reg_cost(X, y, theta)
% Compute cost
m = numel(X);
cost = (0.5/m)*sum((theta(1) + theta(2)*X - y).^2);

% Compute derivative terms
grad = zeros(2,1); % Initialize derivative vector
grad(1) = (1/m)*sum(theta(1) + theta(2)*X - y);
grad(2) = (1/m)*sum((theta(1) + theta(2)*X - y).*X);
end