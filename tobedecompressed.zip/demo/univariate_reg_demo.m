% Create data
X = [1;2;3];
y = [2;4;5];

% Create optimization options
options = optimset('GradObj', 'on', 'MaxIter', 100);

% Create an anonymous function
func = @(theta) univariate_reg_cost(X, y, theta);

init_theta = [0;0]; % Create initial parameters

% Find optimal parameters
[opt_theta, cost_val, exit_flag] = fminunc(func, init_theta, options);

fprintf('The final parameters are:\n');
disp(opt_theta);

fprintf('The final cost is: %f \n', cost_val);
fprintf('The exit flag is: %d \n', exit_flag);
